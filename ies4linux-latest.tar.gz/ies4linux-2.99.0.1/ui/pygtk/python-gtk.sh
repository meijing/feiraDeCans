#!/bin/sh
# Loads Python GTK GUI

debug Using pygtk GUI
load_default_language
python "$IES4LINUX"/ui/pygtk/ies4linux-gtk.py
